package com.hospital.servlet;

import com.hospital.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/slots")
public class SlotServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("add".equals(action)) {
            String doctor = request.getParameter("doctor");
            String slotDate = request.getParameter("slot_date");
            String slotTime = request.getParameter("slot_time");
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO AppointmentSlots (doctor, slot_date, slot_time, available) VALUES (?, ?, ?, TRUE)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, doctor);
                stmt.setString(2, slotDate);
                stmt.setString(3, slotTime);
                stmt.executeUpdate();
                response.sendRedirect(request.getContextPath() + "/jsp/admin_slots.jsp?status=slot_added");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/jsp/admin_slots.jsp?error=Failed to add slot");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/jsp/search_slots.jsp");
        }
    }
}