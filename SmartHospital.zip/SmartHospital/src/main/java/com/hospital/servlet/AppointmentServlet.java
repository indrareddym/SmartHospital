package com.hospital.servlet;

import com.hospital.util.DBConnection;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

@WebServlet("/appointment")
public class AppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
            return;
        }
        if ("request".equals(action)) {
            requestAppointment(request, response, userId);
        } else if ("approve".equals(action) || "reject".equals(action)) {
            handleRequest(request, response);
        }
    }

    private void requestAppointment(HttpServletRequest request, HttpServletResponse response, int userId) throws IOException {
        int slotId = Integer.parseInt(request.getParameter("slot_id"));
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO AppointmentRequests (user_id, slot_id, request_date, status) VALUES (?, ?, CURDATE(), 'pending')";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, slotId);
            stmt.executeUpdate();
            response.sendRedirect(request.getContextPath() + "/jsp/requestAppointment.jsp?slot_id=" + slotId + "&status=requested");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/requestAppointment.jsp?slot_id=" + slotId + "&error=Error requesting appointment");
        }
    }

    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int requestId = Integer.parseInt(request.getParameter("request_id"));
        String status = request.getParameter("action");
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE AppointmentRequests SET status = ?, appointment_date = ? WHERE request_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, status);
            stmt.setString(2, "approved".equals(status) ? "DATE_ADD(CURDATE(), INTERVAL 1 DAY)" : null);
            stmt.setInt(3, requestId);
            stmt.executeUpdate();
            if ("approved".equals(status)) {
                String slotSql = "UPDATE AppointmentSlots SET available = FALSE WHERE slot_id = (SELECT slot_id FROM AppointmentRequests WHERE request_id = ?)";
                PreparedStatement slotStmt = conn.prepareStatement(slotSql);
                slotStmt.setInt(1, requestId);
                slotStmt.executeUpdate();
                sendEmail(requestId, "approved");
            } else {
                sendEmail(requestId, "rejected");
            }
            response.sendRedirect(request.getContextPath() + "/jsp/admin_requests.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/admin_requests.jsp?error=Error processing request");
        }
    }

    private void sendEmail(int requestId, String status) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        String from = "indrareddym22@gmail.com";
        String password = "your_app_password"; // Replace with your Gmail App Password

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT u.email, s.doctor FROM AppointmentRequests ar JOIN Users u ON ar.user_id = u.user_id JOIN AppointmentSlots s ON ar.slot_id = s.slot_id WHERE ar.request_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String to = rs.getString("email");
                String doctor = rs.getString("doctor");
                Session session = Session.getInstance(props, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(from, password);
                    }
                });
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(from));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
                message.setSubject("Appointment Request " + status);
                message.setText("Your appointment request with " + doctor + " has been " + status + ".");
                Transport.send(message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}