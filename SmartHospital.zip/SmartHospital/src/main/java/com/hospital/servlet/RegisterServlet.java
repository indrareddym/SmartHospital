package com.hospital.servlet;

import com.hospital.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String role = request.getParameter("role");
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO Users (username, password, email, role) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, email);
            stmt.setString(4, role);
            stmt.executeUpdate();
            response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?status=registered");
        } catch (SQLException e) {
            e.printStackTrace();
            String errorMessage = "Registration failed";
            if (e.getErrorCode() == 1062) { // MySQL error code for duplicate entry
                errorMessage = "Username or email already exists";
            }
            response.sendRedirect(request.getContextPath() + "/jsp/register.jsp?error=" + java.net.URLEncoder.encode(errorMessage, "UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/register.jsp?error=" + java.net.URLEncoder.encode("Unexpected error occurred", "UTF-8"));
        }
    }
}