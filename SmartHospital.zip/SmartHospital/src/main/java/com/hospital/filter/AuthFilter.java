package com.hospital.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class AuthFilter implements Filter {
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        HttpSession session = request.getSession(false);
        String uri = request.getRequestURI();
        boolean isLoggedIn = session != null && session.getAttribute("user_id") != null;
        String role = session != null ? (String) session.getAttribute("role") : null;

        if (uri.endsWith("login.jsp") || uri.endsWith("register.jsp") || uri.endsWith("login") || uri.endsWith("register")) {
            chain.doFilter(req, resp);
            return;
        }
        if (!isLoggedIn) {
            response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
            return;
        }
        if (uri.contains("admin_") && !"admin".equals(role)) {
            response.sendRedirect(request.getContextPath() + "/slots?action=list");
            return;
        }
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {}
    public void destroy() {}
}